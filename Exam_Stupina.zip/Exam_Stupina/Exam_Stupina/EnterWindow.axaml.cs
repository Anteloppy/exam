using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml;

namespace Exam_Stupina;

public partial class EnterWindow : Window
{
    public EnterWindow()
    {
        InitializeComponent();
    }

    private void Admin_OnClick(object? sender, RoutedEventArgs e)
    {
        MainWindow mw = new MainWindow(true);
        mw.Show();
    }

    private void Manager_OnClick(object? sender, RoutedEventArgs e)
    {
        MainWindow mw = new MainWindow(false);
        mw.Show();
    }
}