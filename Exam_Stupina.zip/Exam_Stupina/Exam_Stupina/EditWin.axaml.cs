using System;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml;

namespace Exam_Stupina;

public partial class EditWin : Window
{
    public EditWin()
    {
        InitializeComponent();
    }
    public EditWin(int id, string lastname, string position, double weight, double height, string birthdate, string start_date, string command)
    {
        InitializeComponent();
        Lid.Content = id;
        TBlastname.Text = lastname;
        TBposition.Text = position;
        TBweight.Text = weight.ToString();
        TBheight.Text = height.ToString();
        TBbirthdate.Text = birthdate;
        TBstart_date.Text = start_date;
        TBcommand.Text = command;
    }

    private void Bedit_OnClick(object? sender, RoutedEventArgs e)
    {
        int p = 0, c = 0;
        switch (TBposition.Text)
        {
            case "нападающий": p = 1; break;
            case "защитник": p = 2; break;
            default: return;
        }
        switch (TBcommand.Text)
        {
            case "красные": c = 1; break;
            case "синие": c = 2; break;
            default: return;
        }
        MainWindow mw = new MainWindow(true);
        mw.LoadData("update players set lastname = '" + TBlastname.Text + "', position = " + p + ", weight = " + Convert.ToDouble(TBweight.Text) + ", height = "  + Convert.ToDouble(TBheight.Text) + ", birthdate = '" + TBbirthdate.Text + "', start_date = '" + TBstart_date.Text + "', command = " + c);
        mw.Show();
    }
}