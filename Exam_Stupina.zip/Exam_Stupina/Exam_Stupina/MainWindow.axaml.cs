using System.Collections.Generic;
using Avalonia.Controls;
using Avalonia.Interactivity;
using MySql.Data.MySqlClient;

namespace Exam_Stupina;

public partial class MainWindow : Window
{
    public string sql = "select p.id, p.lastname, o.name as position, p.weight, p.height, p.birthdate, p.start_date, c.name as command from players as p join positions as o on p.position = o.id join commands as c on p.command = c.id";
    public MainWindow()
    {
        InitializeComponent();
        LoadData(sql);
    }
    public MainWindow(bool role)
    {
        InitializeComponent();
        Bedit.IsVisible = role;
        if (role == true)
            Lrole.Content = "Администратор";
        else Lrole.Content = "Менеджер";
        LoadData(sql);
    }

    private static string connectionString = "server = localhost; port = 3306; database = exam; user = root; password = Admin123";

    public void LoadData(string sql)
    {
        List<Player> players = new List<Player>();
        using (MySqlConnection conn = new MySqlConnection(connectionString))
        {
            conn.Open();
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            using (MySqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    Player record = new Player();
                    record.id = reader.GetInt32("id");
                    record.lastname = reader.GetString("lastname");
                    record.position = reader.GetString("position");
                    record.weight = reader.GetDouble("weight");
                    record.height = reader.GetDouble("height");
                    record.birthdate = reader.GetDateTime("birthdate").ToString("yyyy-MM-dd");
                    record.start_date = reader.GetDateTime("start_date").ToString("yyyy-MM-dd");
                    record.command = reader.GetString("command");
                    players.Add(record);
                }
            }
        }
        DGplayers.ItemsSource = players;
    }

    private void Bedit_OnClick(object? sender, RoutedEventArgs e)
    {
        Player si = (Player)DGplayers.SelectedItem;
        EditWin ew = new EditWin(si.id, si.lastname, si.position, si.weight, si.height, si.birthdate, si.start_date, si.command);
        ew.Show();
        this.Close();
    }

    private void Bdelete_OnClick(object? sender, RoutedEventArgs e)
    {
        Player si = (Player)DGplayers.SelectedItem;
        LoadData("delete from players where id = " + si.id);
    }

    private void Bexit_OnClick(object? sender, RoutedEventArgs e)
    {
        EnterWindow ew = new EnterWindow();
        ew.Show();
        this.Close();
    }

    private void CBfilter_OnSelectionChanged(object? sender, SelectionChangedEventArgs e)
    {
        if (TBfind.Text == "")
            Filter();
        else
        {
            string text = TBfind.Text;
            string select = sql + " where lastname like '%" + text + "%'";
            int si = CBfilter.SelectedIndex;
            switch (si)
            {
                case 0: break;
                case 1: select += " where p.position like " + 1; break;
                case 2: select += " where p.position like " + 2; break;
            }
            LoadData(select);
        }
    }

    private void TBfind_OnTextChanged(object? sender, TextChangedEventArgs e)
    {
        if (CBfilter.SelectedIndex == 0)
            Find();
        else
        {
            string text = TBfind.Text;
            string select = sql + " where lastname like '%" + text + "%'";
            int si = CBfilter.SelectedIndex;
            switch (si)
            {
                case 1: select += " where p.position like " + 1; break;
                case 2: select += " where p.position like " + 2; break;
            }
            LoadData(select);
        }
    }

    public void Find()
    {
        string text = TBfind.Text;
        if (text != "")
            LoadData(sql + " where lastname like '%" + text + "%'");
        else LoadData(sql);
    }

    public void Filter()
    {
        int si = CBfilter.SelectedIndex;
        switch (si)
        {
            case 0: LoadData(sql); break;
            case 1: LoadData(sql + " where p.position like " + 1); break;
            case 2: LoadData(sql + " where p.position like " + 2); break;
        }
    }
}