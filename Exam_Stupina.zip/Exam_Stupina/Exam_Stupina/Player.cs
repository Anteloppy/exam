namespace Exam_Stupina;

public class Player
{
    public int id { get; set; }
    public string lastname { get; set; }
    public string position { get; set; }
    public double weight { get; set; }
    public double height { get; set; }
    public string birthdate { get; set; }
    public string start_date { get; set; }
    public string command { get; set; }
}