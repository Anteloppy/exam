namespace TestProject1;

public class UnitTest1
{
    public double Calc(int v)
    {
        double g = 9.8;
        double t = 2*v/g;
        return t;
    }
    [Fact]
    public void Test1()
    {
        int v = 8;
        double expected = 1.6326530612244896;
        double actual = Calc(v);
        Assert.Equal(expected, actual);
    }
    [Fact]
    public void Test2()
    {
        int v = 4;
        double expected = 0.81632653061224481;
        double actual = Calc(v);
        Assert.Equal(expected, actual);
    }
}